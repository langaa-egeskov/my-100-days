 	====================================================
 	some_package: Demonstrate packaging and distribution
 	====================================================
 	
 	``some_package`` is the Python package to demostrate how easy it is
 	to create installable, maintainable, shareable packages and distributions.
 	
 	It does contain one function, called ``some_func()``.
 	
 	.. code-block
 	
 	   >>> import some_package
 	   >>> some_package.some_func()
 	   42
 	
 	
 	That's it, really.
